import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.junit.Before;
import org.junit.Test;

public class ContextTest {

	/**
	   * Verify if the interface uses the strategy during process
	   */
	private String str=null;
	private File filename;
	private InputStream is;
	BufferedReader buf;
	@Before
	public void setUp()
	{
		is = null;
		filename= new File("conTest.txt");
		
		try {
			is = new FileInputStream(filename);
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		buf = new BufferedReader(new InputStreamReader(is));
		try {
			String line2 = buf.readLine();
			StringBuilder sb = new StringBuilder();
			while (line2 != null) {
				sb.append(line2).append("\n");
				line2 = buf.readLine();
			}

			str = sb.toString();
		//System.out.println(str);
		
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}
	  @Test
	  public void StartWork() 
	  {
	     Strategy strategy = mock(Strategy.class);
	     Context context = new Context(strategy);
	     assertNotNull(context);
	    
	    context.StartWork(filename);
	    verify(strategy).execute(str);
	    verifyNoMoreInteractions(strategy);
		
	  }

	  /**
	   * Verify if the dragon slayer uses the new strategy during battle after a change of strategy
	   */
	  @Test
	  public void testChangeStrategy() throws Exception {
	    final Strategy initialStrategy = mock(Strategy.class);
	    final Context context = new Context(initialStrategy);

	    context.StartWork(filename);
	    verify(initialStrategy).execute(str);

	    final Strategy newStrategy = mock(Strategy.class);
	    context.changeStrategy(newStrategy);

	    context.StartWork(filename);
	    verify(newStrategy).execute(str);

	    verifyNoMoreInteractions(initialStrategy, newStrategy);
	 }

	}