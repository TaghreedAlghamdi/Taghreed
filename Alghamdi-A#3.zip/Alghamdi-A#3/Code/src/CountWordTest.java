import static org.junit.Assert.*;

import java.io.File;

import org.junit.Before;
import org.junit.Test;

public class CountWordTest {
	
	
	// @Parameterized.Parameters
	

	private String best,result,actual;
	private File file;
	private CountWord cw;
	@Before
	public void setUp()
	{
	cw= new CountWord();

	ReadingFileTest readfile = new ReadingFileTest();
	 try {
			assertNotNull(cw);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	 try {
			assertNotNull(readfile);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
}
	
	

	@Test
	public void test() {
		best= "wd j\nh\njj";

		actual= "Total Number of Lines is: 3"  +"\n" + "Total Number of Words is: 4" + "\n" + "Total Number of characters is: 6" ;

		result=cw.execute(best);
		assertEquals(actual,result);
	}
	
	@Test
	public void testLongString() {
		best= "wd jjjj\nhhhh\njkkklll";
		actual= "Total Number of Lines is: 3"  +"\n" + "Total Number of Words is: 4" +"\n" +"Total Number of characters is: 17";

		result=cw.execute(best);
		assertEquals(actual,result);
	}

	@Test
	public void tesOneLine() {
		best= "\n";
		actual= "Total Number of Lines is: 1"  +"\n" + "Total Number of Words is: 0" +"\n" +"Total Number of characters is: 0";

		result=cw.execute(best);
		
		assertEquals(actual,result);
	}
	
	
	 
	     


}
