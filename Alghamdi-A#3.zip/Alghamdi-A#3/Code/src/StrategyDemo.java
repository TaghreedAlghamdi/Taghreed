import java.io.File;



public class StrategyDemo {
	

	public static void main(String[] args) 
	
	{
		
		File filename=new File(args[args.length-1]);
		String operation=args[1];
		
		Context context = new Context(new CountWord());
		System.out.println("start methods");
		
		System.out.println("Welcom to CSCE553");
		System.out.println("Start Reading File");

		

		
		switch(operation) {
		case "wc":
			context.StartWork(filename);
			System.out.println("Counting program for Word");
			break;
			
			
		case "grep":
			String operation2= args[2];
			context.changeStrategy(new FindWord(operation2));
			context.StartWork(filename);
			System.out.println("Searching for Word");

			break;
			
			
		case "Freq":
			context.changeStrategy(new FreqWord());
			context.StartWork(filename);
			System.out.println("Welcom to Frequnency");
			break;
			
			default:
				break;
			
		
		}
        
	   
        
	}
	}
        


