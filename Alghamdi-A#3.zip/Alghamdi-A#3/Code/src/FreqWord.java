import java.util.ArrayList;
import java.util.Scanner;
import java.util.StringTokenizer;

public class FreqWord implements Strategy {
	char [] array;
	String list="";
	//StringTokenizer parser;
	ArrayList<String> Search_Word = new ArrayList<String>();
	ArrayList<Integer> Word_Freq = new ArrayList<Integer>();

	@Override
	
	public String execute(String cmnd1) {


		
		Scanner fileInput = new Scanner(cmnd1);
		//Scanner scanner = new Scanner(null);
		// parser = new StringTokenizer(cmnd1, " \t\n\r\f.,;:!?'\""); 
			 while(fileInput.hasNext())
			//while(parser.hasMoreTokens())

			 {
					String currentWord = fileInput.next();
					 if(Search_Word.contains(currentWord))
					 {
						 
					int frequency = Search_Word.indexOf(currentWord); 
					Word_Freq.set(frequency, Word_Freq.get(frequency) + 1);
					 }
					 else
					 {
						 Search_Word.add(currentWord);
						 Word_Freq.add(1);	
					 }
					
			 }
				
			fileInput.close();
			/*	for (int i = 0; i < Search_Word.size(); i++) 
				{			
					System.out.println(Search_Word.get(i) + " is found: " + Word_Freq.get(i) + "times");

					list+= Search_Word.get(i) + " is found: " + Word_Freq.get(i) + "times" + "\n";

				}*/
			for (int i = 0; i < Search_Word.size(); i++) 
			{			

				list+= Search_Word.get(i) + " is found: " + Word_Freq.get(i) + "times" + "\n";

			}System.out.println(list);
				return list;
	}

	/*@Override
	public void result() 
	{
		System.out.println(list);

		 System.out.println ("You are in Frequenncy Words Method");
		 

	}
*/
}
