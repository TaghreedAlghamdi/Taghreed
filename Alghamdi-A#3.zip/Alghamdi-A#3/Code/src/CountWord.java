
public class CountWord implements Strategy {

		String[] words;
		String[] array;
	 	int count_words=0;
	 	 int count_lines=0;
	     int count_chars=0;
		
	@Override
	public String execute(String cmnd1) 
	{
		
		words=cmnd1.split("\\s+");

		count_words+=words.length;
		
		char array[] = cmnd1.toCharArray();
		//StringBuffer sb = new StringBuffer();
		 for (int j = 0; j < array.length; j++)
	        {
	            if( (array[j] != ' ') && (array[j] != '\n') )
	            	count_chars ++;
	            
	            if(array[j]=='\n') 
	            	count_lines++;
	            
				
	       }
		
			if(array[array.length-1]!='\n') count_lines++;
		
	
		String result= "Total Number of Lines is: " +count_lines +"\n" + "Total Number of Words is: " + count_words+ "\n" +"Total Number of characters is: " + count_chars;
		System.out.println(result);
		return result;

	}
		// TODO Auto-generated method stub
		
	


	/*public void result() {
		
		System.out.println ("You are in Counting Words Method"); 
	    System.out.println ("The file dierctory is at:");
	    System.out.println(System.getProperty("user.dir"));
		System.out.println("Total Number of Lines is: " + count_lines);
		System.out.println("Total Number of Words is: " + count_words);
		System.out.println("Total Number of Charecter is: " + count_chars);
		
		
	}*/
}
