import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class ReadingFileTest {
	
	public String ReadingFile() {
		  InputStream is = null;
			String line = null;
			try {
				is = new FileInputStream("src/filenametest.txt");
			} catch (FileNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			BufferedReader buf = new BufferedReader(new InputStreamReader(is));
			try {
				String line2 = buf.readLine();
				StringBuilder sb = new StringBuilder();
				while (line2 != null) {
					sb.append(line2).append("\n");
					line2 = buf.readLine();
				}

				line = sb.toString();
		  
			
		}
			catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		return line;
		

		}
	}



