
public interface Strategy {
	

	public String execute(String cmnd1);  // execute method

	//public void result();

}
