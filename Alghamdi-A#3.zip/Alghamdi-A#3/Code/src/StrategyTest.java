import static org.junit.Assert.*;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Arrays;
import java.util.Collection;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;
@RunWith(Parameterized.class)
public class StrategyTest 

{
		 @Parameterized.Parameters 

		  public static Collection<Object[]> data() 
		  {
			  return Arrays.asList(
				        new Object[]{
				            new CountWord(),
				            		"Total Number of Lines is: 1"  +"\n" + "Total Number of Words is: 3" + "\n" + "Total Number of characters is: 8"

				        },
				        new Object[]{
				                new FindWord("it"),
					            "We found the word which is:it"
				        },
				        new Object[]{
				                new FreqWord(),
				                "it is found: 1times\nis is found: 1times\nhard is found: 1times\n"				            }
				        );}
		  /**
		   * The tested strategy
		   */
		  private final Strategy strategy; 
		  /**
		   * The expected action in the execute
		   */
		  private final String expectedResult;
		  private  String myString;
		 
		  @Before
		  public void setUp() 
		  {
			  myString="it is hard";
		   
		  }
		  
	/**
	 * Create a new test instance for the given strategy
	 *
	 * strategy	 		==>> The tested strategy
	 * expectedResult	==>> The expected result
	 */
		  public StrategyTest(final Strategy strategy, final String expectedResult)
		  {
			    this.strategy = strategy;
			    this.expectedResult = expectedResult;
		  }
		  
		  /**
		   * Test if executing the strategy gives the correct response
		   */
		  
		  @Test
		public void testStartWork()
		  {
			  assertEquals(this.strategy.execute(myString),this.expectedResult);
			  }
 
	}