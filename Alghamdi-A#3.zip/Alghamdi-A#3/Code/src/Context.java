import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;



public class Context {

	
	private Strategy strategy;

	  public Context(Strategy strategy) {
	    this.strategy = strategy;
	  }
	  
	  public void changeStrategy(Strategy strategy) {
		    this.strategy = strategy;
		  }

	  public String StartWork(File filename) {
		
		  InputStream is = null;
			String line = null;
			try {
				is = new FileInputStream(filename);
			} catch (FileNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			BufferedReader buf = new BufferedReader(new InputStreamReader(is));
			try {
				String line2 = buf.readLine();
				StringBuilder sb = new StringBuilder();
				while (line2 != null) {
					sb.append(line2).append("\n");
					line2 = buf.readLine();
				}

				line = sb.toString();
		  
				 strategy.execute(line);
		      
			
		  //strategy.result();
	  }catch (Exception e)
				  {
					e.printStackTrace();
				}
				return line;
			}

		}


				  
		  
		  
		/* // String cmnd2 = null ;
		  try {
			// FileReader reads text files in the default encoding.
	            //FileReader fileReader = new FileReader(filename);
				// Always wrap FileReader in BufferedReader.
			  BufferedReader fr = new BufferedReader (new FileReader(filename));
			  String line ;

				System.out.println ("Opend file ....");
				 
			   while ((line= fr.readLine() )!= null)
			      {
					//System.out.println ("It's readin now ...."); 

				   strategy.execute(line);
			      }	
			   strategy.result();

			   fr.close();
			   }
		  catch (Exception e)
		  {
		    System.err.format("Exception occurred trying to read '%s'.", filename);
		    e.printStackTrace();
	    }
	}*/

