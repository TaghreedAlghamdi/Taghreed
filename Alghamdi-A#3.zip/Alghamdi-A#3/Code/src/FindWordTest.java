import static org.junit.Assert.*;

import java.io.File;

import org.junit.Before;
import org.junit.Test;

public class FindWordTest {
	 //@Parameterized.Parameters
	private String text,result,actual;
	private File file;
	private FindWord fw;
	private String word;

	@Before
	public void setUp()
	{
	fw= new FindWord("");

	try {
		assertNotNull(fw);
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

	}

	@Test
	public void test() {
		word = "wd";
		fw= new FindWord(word);
		text= "wd dd ss"; 
		assertEquals("We found the word which is:" + word, fw.execute(text));
	}
	
	
	

	@Test
	public void testEmpty() {

	    assertFalse("We found the word which is: wd", false); 
	}
	@Test
	public void testEmptyNull() {
	      assertNull("We found the word which is:", null);

	  }
	@Test
	public void testNotSame() {

	    assertNotSame("We found the word which is: wd", "expected", "actual");

	  }
	}


