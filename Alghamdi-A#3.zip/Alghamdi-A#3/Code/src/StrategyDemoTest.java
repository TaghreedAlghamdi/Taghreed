import static org.junit.Assert.*;

import java.io.File;
import java.io.FileInputStream;
import java.util.Arrays;
import java.util.Collection;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.objenesis.tck.Main;
import org.omg.CORBA.portable.InputStream;


@RunWith(Parameterized.class)

public class StrategyDemoTest {

	@Parameterized.Parameters

	 public static Collection<Object[]> data() 
	  {
		  return Arrays.asList(
			        new Object[]{
			           new Context(new CountWord()), "Context"
			            
			        },
			        new Object[]{
			        	 new Context (new FindWord("")),"Context"
				            
	
			        },
			        new Object[]{
			        	new Context(new FreqWord()), "Context"
			        }
			        );
	  				}
		
	 	private String []args;
	   private Main mymain;
	   private String v1,v2;
	   private Context context,c;
	   @Before
	   public void setUp()
	   {
	       String comand= "wc grep Freq";
	      
	   }
	  
	   public StrategyDemoTest (final Context context1, final String v3 )
	   {
	       this.c= context1;
	       this.v2=v3;
	   }
	  
	   @Test
	   
	      
	       public void testWc()
	       {
	      
	       assertEquals( c.getClass().getName(), v2);
	      
	       
	   }
	  
	  
	  
	}