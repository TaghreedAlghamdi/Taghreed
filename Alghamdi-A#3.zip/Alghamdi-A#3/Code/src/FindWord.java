import java.util.Arrays;

public class FindWord implements Strategy {
	Boolean found;
	private String word,result;
	public FindWord(String word) 
	{
		//super();
		this.word = word;
	}
	@Override
	public String execute(String line)
	{		
		//found = Arrays.asList(line.split(" ")).contains(word);
		//if(found)
		//System.out.println("The word you are looking for is: " + word);
		if (line.contains(word))
		  		 
		 {
			result="We found the word which is:" + word;
	        	System.out.println(result);
	      
	        
		 }
		
			else  
			{ result= "Word is not found ";
				System.out.println(result);
			
			}
			
			return result;
			//return word + "Your Finding Words Method is working"; 
		}

/*	@Override
	public void result() {
		 System.out.println ("You are in Finding Words Method"); 
		 System.out.println ("The file dierctory is at:");
		 System.out.println(System.getProperty("user.dir"));
		 System.out.println ("You are in Finding Words Method");

	}*/

}
