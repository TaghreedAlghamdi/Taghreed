import static org.junit.Assert.*;

import java.io.File;
import java.util.Arrays;
import java.util.Collection;
import java.util.LinkedList;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

@RunWith(Parameterized.class)


public class FindWordTestParameterized {
	
	private FindWord fw;
	private String word;
	private String actual,expected;

	 @Parameterized.Parameters
	 
	 
	 
	 
	 public static Collection<Object[]> data() {
         return Arrays.asList(
             new Object[]{
                     "hey", "We found the word which is:hey"
                     //"We found the word which is "+word, fw.execute(text));
             },
             new Object[]{
                     "name", "We found the word which is:name"

             },
             new Object[]
                     {
                             "taghreed", "We found the word which is:taghreed"
                     }
   
         );
       }
  
	

	 @Before
     public void setUp()
     {
		 fw= new FindWord(expected);
		 }
	 
     public FindWordTestParameterized(final String expected, final String actual ) {
    	 this.expected= expected;
         this.actual=actual;
        
     }
    
   @Test
   public final void test() {
       //fail("Not yet implemented"); // TODO
	   fw= new FindWord(expected);
       assertEquals(actual,fw.execute("name is taghreed hey how are you"));
	   //assertEquals(expected,fw.execute(actual));
      
   }
   


}