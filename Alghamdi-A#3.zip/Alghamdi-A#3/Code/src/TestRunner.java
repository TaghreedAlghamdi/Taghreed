import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;

import junit.framework.TestSuite;

public class TestRunner {

	public static void main (String[]args)
	{
		Result r=JUnitCore.runClasses(TestSuiteforAll.class);
		for(Failure failure:r.getFailures())
		{
			System.out.println(failure.toString());
		}
		System.out.println(r.wasSuccessful());
	}

}
