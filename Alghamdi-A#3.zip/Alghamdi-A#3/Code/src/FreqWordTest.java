import static org.junit.Assert.*;

import java.io.File;

import org.junit.Before;
import org.junit.Test;

public class FreqWordTest {

	private String best, result, actual, file;
	// private File file;
	private FreqWord fq;
	private ReadingFileTest readfile;

	@Before
	public void setUp() {
		fq = new FreqWord();
		readfile = new ReadingFileTest();

		try {
			assertNotNull(fq);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			assertNotNull(readfile);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void test() {
		// file = new String(readfile.ReadingFile());
		best = "aa aa bb dd";
		fq = new FreqWord();
		assertEquals("aa is found: 2times\nbb is found: 1times\ndd is found: 1times\n", fq.execute(best));

	}
	
	@Test
	public void testA() {
		// file = new String(readfile.ReadingFile());
		best = "name\naa nn dd\nbb dd";
		fq = new FreqWord();
		assertEquals("name is found: 1times\naa is found: 1times\nnn is found: 1times\ndd is found: 2times\nbb is found: 1times\n", fq.execute(best));

	}
	@Test

	public void testFromFile() {
		 file = new String(readfile.ReadingFile());
		fq = new FreqWord();
		assertEquals("aa is found: 2times\nbb is found: 1times\ncc is found: 1times\ntt is found: 1times\n", fq.execute(file));

	}	

}
