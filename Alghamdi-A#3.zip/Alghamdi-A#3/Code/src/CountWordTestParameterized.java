import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.Collection;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

@RunWith(Parameterized.class)


public class CountWordTestParameterized {

	private CountWord wc;
    private final String expected, actual;
	 @Parameterized.Parameters

	 public static Collection<Object[]> data() {
         return Arrays.asList(
             new Object[]{

  //   "Total Number of Lines is: " +count_lines +"\n" + "Total Number of Words is: " + count_words+ "\n" +"Total Number of characters is: " + count_chars;
            			
            		 
              "aa", "Total Number of Lines is: 1" +"\n" + "Total Number of Words is: 1" +"\n" +"Total Number of characters is: 2" 


             },
            
             new Object[]
                     {
               "this\nis\nvery", "Total Number of Lines is: 3" +"\n" + "Total Number of Words is: 3" +"\n" +"Total Number of characters is: 10"
                     },
                    
                      new Object[]
                             {
                    "I\nam\nhere","Total Number of Lines is: 3" +"\n" + "Total Number of Words is: 3" +"\n" +"Total Number of characters is: 7"   
                             }
            
         );
       }
  
  
   @Before
   public void setUp()
   {
      wc= new CountWord();
      
   }
   public CountWordTestParameterized(final String expected, final String actual ) {
 	 this.expected= expected;
      this.actual=actual;
    
      
   }
  
 @Test
 public final void test() {
	   wc= new CountWord();

     //fail("Not yet implemented"); // TODO
     assertEquals(actual,wc.execute(expected));
    
 }

}