import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.Collection;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameter;



@RunWith(Parameterized.class)


	public class FreqWordTestParameterized {
    private FreqWord fq;
    private final String expected, actual;
    
	 @Parameterized.Parameters

      public static Collection<Object[]> data() {
            return Arrays.asList(
                new Object[]{
                        "hello hello me", "hello is found: 2times\nme is found: 1times\n"
                },
               
                new Object[]
                        {
                  "this is very very \n hard", "this is found: 1times\nis is found: 1times\nvery is found: 2times\nhard is found: 1times\n"
                        },
                       
                         new Object[]
                                {
                       "Iam \n\nlearning more \n and\nmore","Iam is found: 1times\nlearning is found: 1times\nmore is found: 2times\nand is found: 1times\n"    
                                }
               
            );
          }
     
     
      @Before
      public void setUp()
      {
         fq= new FreqWord();
         
      }
      public FreqWordTestParameterized(final String expected, final String actual ) {
    	 this.expected= expected;
         this.actual=actual;
       
         
      }
     
    @Test
    public final void test() {
 	   fq= new FreqWord();

        //fail("Not yet implemented"); // TODO
        assertEquals(actual,fq.execute(expected));
       
    }
 
}